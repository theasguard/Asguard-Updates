from asguard_lib import db_utils
import json
from asguard_lib import client
import logging
import requests
import cache

logger = logging.getLogger(__name__)

class TVDBAPI:
    def __init__(self):
        self.apiKey = {'apikey': 'b64a2c35-ba29-4353-b46c-1e306874afb6', 'pin': ''}
        self.headers = {'User-Agent': 'Asguard'}
        self.baseUrl = 'https://api4.thetvdb.com/v4/'
        self.art = {}
        self.request_response = None
        self.threads = []

    def get_token(self):
        res = client.request(self.baseUrl + 'login', headers=self.headers, post=self.apiKey, jpost=True)
        data = json.loads(res)
        return data['data'].get('token')

    def get_request(self, url):
        token = cache.get(self.get_token, 24)
        self.headers.update({'Authorization': f'Bearer {token}'})
        url = self.baseUrl + url

        response = client.request(url, headers=self.headers)
        if response:
            response = json.loads(response).get('data')
            self.request_response = response
            return response
        else:
            return None

    def get_imdb_id(self, tvdb_id):
        imdb_id = None
        url = 'series/{}/extended'.format(tvdb_id)
        data = self.get_request(url)
        if data:
            imdb_id = [x.get('id') for x in data['remoteIds'] if x.get('type') == 2]
        return imdb_id[0] if imdb_id else None

    def get_seasons(self, tvdb_id):
        url = 'seasons/{}/extended'.format(tvdb_id)
        data = self.get_request(url)
        return data
    
    def get_episodes(self, tvdb_id, season_number):
        url = f'series/{tvdb_id}/episodes?season={season_number}'
        data = self.get_request(url)
        return data

    def get_series_extended(self, tvdb_id):
        try:
            res = self.get_request(f"series/{tvdb_id}/extended?meta=episodes&short=false")
            if not res:  # Add null check for response
                logger.error('TVDB API request returned empty response')
                return None
                
            data = res
            if data.get('status') != 'success':
                logger.error(f"TVDB API failed: {data.get('message', 'Unknown error')}")
                return None
                
            series_data = data
            return {
                'id': series_data['id'],
                'title': series_data.get('name'),
                'year': series_data.get('year'),
                'plot': series_data.get('overview'),
                'episodes': self._parse_episodes(series_data.get('episodes', [])),
                'art': self._parse_artwork(series_data.get('artworks', [])),
                'genres': [g['name'] for g in series_data.get('genres', [])],
                'status': series_data.get('status', {}).get('name'),
                'rating': series_data.get('score'),
                'network': series_data.get('originalNetwork', {}).get('name')
            }
            
        except Exception as e:
            logger.error(f"Failed to get series data: {str(e)}")
            return None

    def _parse_episodes(self, episodes):
        parsed = []
        for ep in episodes:
            if not ep.get('aired'):
                continue
            
            parsed.append({
                'episode_id': ep['id'],
                'season': ep.get('seasonNumber', 0),
                'episode': ep.get('number', 0),
                'title': ep.get('name'),
                'aired': ep.get('aired'),
                'runtime': ep.get('runtime'),
                'plot': ep.get('overview'),
                'image': self._full_image_url(ep.get('image')),
                'absolute_number': ep.get('absoluteNumber'),
                'finale_type': ep.get('finaleType')
            })
        return parsed

    def _parse_artwork(self, artworks):
        return {
            'poster': next((a['image'] for a in artworks if a['type'] == 2), None),
            'fanart': next((a['image'] for a in artworks if a['type'] == 3), None)
        }

    def _full_image_url(self, path):
        if path and not path.startswith('http'):
            return f"https://artworks.thetvdb.com{path}"
        return path
