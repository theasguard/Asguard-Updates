__all__ = ["AllDebridResolver"]

from .all_debrid import AllDebridResolver
