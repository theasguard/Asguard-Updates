# -*- coding: UTF-8 -*-
#######################################################################
 # ----------------------------------------------------------------------------
 # "THE BEER-WARE LICENSE" (Revision 42):
 # @Daddy_Blamo wrote this file.  As long as you retain this notice you
 # can do whatever you want with this stuff. If we meet some day, and you think
 # this stuff is worth it, you can buy me a beer in return. - MrBlamo
 # ----------------------------------------------------------------------------
#######################################################################

# Addon Name: Asguard
# Addon id: plugin.video.asguard
# Addon Provider: MrBlamo


import os
import re
import time
import six
from xml.dom import minidom
from scrapers import scraper
from scrapers import proxy
import kodi
import log_utils  # @UnusedImport
from asguard_lib import utils2
from asguard_lib.constants import FORCE_NO_MATCH
from asguard_lib.constants import VIDEO_TYPES
from asguard_lib import control

files = os.listdir(os.path.dirname(__file__))
__all__ = [filename[:-3] for filename in files if not filename.startswith('__') and filename.endswith('.py')]

from . import *

logger = log_utils.Logger.get_logger()
  
class ScraperVideo:
    def __init__(self, video_type, title, year, trakt_id, season='', episode='', ep_title='', ep_airdate=''):
        """
        Constructs all the necessary attributes for the ScraperVideo object.

        Args:
            video_type (str): The type of video (e.g., movie, TV show, episode).
            title (str): The title of the video.
            year (str): The release year of the video.
            trakt_id (str): The Trakt ID of the video.
            season (str, optional): The season number (for TV shows). Defaults to ''.
            episode (str, optional): The episode number (for TV shows). Defaults to ''.
            ep_title (str, optional): The title of the episode (for TV shows). Defaults to ''.
            ep_airdate (str, optional): The air date of the episode in the format 'YYYY-MM-DD' (for TV shows). Defaults to None.
        """
        assert(video_type in (VIDEO_TYPES.__dict__[k] for k in VIDEO_TYPES.__dict__ if not k.startswith('__')))
        self.video_type = video_type
        if isinstance(title, bytes): self.title = title.encode('utf-8')
        else: self.title = title
        self.year = str(year)
        self.season = season
        self.episode = episode
        if isinstance(ep_title, bytes): self.ep_title = ep_title.encode('utf-8')
        else: self.ep_title = ep_title
        self.trakt_id = trakt_id
        self.ep_airdate = utils2.to_datetime(ep_airdate, "%Y-%m-%d").date() if ep_airdate else None

    def __str__(self):
        return '|%s|%s|%s|%s|%s|%s|%s|' % (self.video_type, self.title, self.year, self.season, self.episode, self.ep_title, self.ep_airdate)

class ScraperVideoExtended(ScraperVideo):
    def __init__(self, video_type, title, year, trakt_id, season='', episode='', ep_title='', ep_airdate='', aliases=None, anidb_id=None, mal_id=None, anilist_id=None):
        """
        Constructs all the necessary attributes for the ScraperVideoExtended object.

        Args:
            video_type (str): The type of video (e.g., movie, TV show, episode).
            title (str): The title of the video.
            year (str): The release year of the video.
            trakt_id (str): The Trakt ID of the video.
            season (str, optional): The season number (for TV shows). Defaults to ''.
            episode (str, optional): The episode number (for TV shows). Defaults to ''.
            ep_title (str, optional): The title of the episode (for TV shows). Defaults to ''.
            ep_airdate (str, optional): The air date of the episode in the format 'YYYY-MM-DD' (for TV shows). Defaults to None.
            aliases (list, optional): List of aliases for the video. Defaults to None.
            anidb_id (str, optional): The AniDB ID of the video. Defaults to None.
            mal_id (str, optional): The MyAnimeList ID of the video. Defaults to None.
            anilist_id (str, optional): The AniList ID of the video. Defaults to None.
        """
        super().__init__(video_type, title, year, trakt_id, season, episode, ep_title, ep_airdate)
        self.aliases = aliases if aliases else []
        self.anidb_id = anidb_id
        self.mal_id = mal_id
        self.anilist_id = anilist_id

    def __str__(self):
        return super().__str__() + '|%s|%s|%s|%s|' % (self.aliases, self.anidb_id, self.mal_id, self.anilist_id)

def update_xml(xml, new_settings, cat_count):
    # Convert list of settings to XML string
    # Map category numbers to their corresponding language string IDs
    CATEGORY_LABELS = {
        1: 30318,  # Scrapers 1
        2: 30319,  # Scrapers 2
        3: 30320,  # Scrapers 3
        4: 30321,  # Scrapers 4
        5: 30322,  # Scrapers 5
        6: 30323,  # Scrapers 6
        7: 40710,  # Scrapers 7
        8: 40711,  # Scrapers 8
        9: 40712,  # Scrapers 9
        10: 40713,  # Scrapers 10
        11: 40714,  # Scrapers 11
        12: 40715,  # Scrapers 12
        # Add more mappings as needed
    }
    settings_str = '\n'.join(new_settings)
    category_label = CATEGORY_LABELS.get(cat_count, 'Scrapers %s' % cat_count)
    category_tag = '<category id="scrapers_%s" label="%s">\n%s\n</category>' % (cat_count, category_label, settings_str)
    
    # Find existing category block
    pattern = r'(<category id="scrapers_%s" label="%s">.*?</category>)' % (cat_count, category_label)
    match = re.search(pattern, xml, re.DOTALL)
    
    if match:
        # Replace existing category content
        old_category = match.group(1)
        xml = xml.replace(old_category, category_tag)
    else:
        # Add new category at the end before closing </settings>
        xml = xml.replace('</settings>', '%s\n</settings>' % category_tag)
    
    return xml

def update_settings():
    full_path = os.path.join(kodi.get_path(), 'resources', 'settings.xml')
    logger.log('Updating settings: %s' % (full_path), log_utils.LOGDEBUG)
    
    try:
        with open(full_path, 'r+') as f:
            xml = f.read()
            original_xml = xml
            
            new_settings = []
            cat_count = 1
            classes = scraper.Scraper.__class__.__subclasses__(scraper.Scraper)
            classes += proxy.Proxy.__class__.__subclasses__(proxy.Proxy)
            
            for cls in sorted(classes, key=lambda x: x.get_name().upper()):
                if not cls.get_name() or cls.has_proxy():
                    continue
                
                # Get settings as XML strings
                settings = cls.get_settings()
                if isinstance(settings, list):
                    new_settings.extend(settings)
                else:
                    new_settings.append(settings)
                
                if len(new_settings) > 15:  # More frequent updates
                    xml = update_xml(xml, new_settings, cat_count)
                    new_settings = []
                    cat_count += 1
            
            if new_settings:
                xml = update_xml(xml, new_settings, cat_count)
            
            if xml != original_xml:
                f.seek(0)
                f.write(xml)
                f.truncate()
                logger.log('Settings updated successfully', log_utils.LOGDEBUG)
            else:
                logger.log('No settings changes detected', log_utils.LOGDEBUG)
                
    except Exception as e:
        logger.log('Settings update failed: %s' % str(e), log_utils.LOGERROR)
        raise


def update_all_scrapers():
    try:
        last_check = int(kodi.get_setting('last_list_check'))
    except:
        last_check = 0
    now = int(time.time())
    list_url = kodi.get_setting('scraper_url')
    scraper_password = kodi.get_setting('scraper_password')
    list_path = os.path.join(kodi.translate_path(kodi.get_profile()), 'scraper_list.txt')
    exists = os.path.exists(list_path)
    if list_url and scraper_password and (not exists or (now - last_check) > 15 * 60):
        _etag, scraper_list = utils2.get_and_decrypt(list_url, scraper_password)
        if scraper_list:
            try:
                with open(list_path, 'w') as f:
                    f.write(scraper_list)

                kodi.set_setting('last_list_check', str(now))
                kodi.set_setting('scraper_last_update', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(now)))
                for line in scraper_list.split('\n'):
                    line = line.replace(' ', '')
                    if line:
                        scraper_url, filename = line.split(',')
                        if scraper_url.startswith('http'):
                            update_scraper(filename, scraper_url)
            except Exception as e:
                logger.log('Exception during scraper update: %s' % (e), log_utils.LOGWARNING)

def update_scraper(filename, scraper_url):
    try:
        if not filename:
            return
        py_path = os.path.join(kodi.get_path(), 'scrapers', filename)
        exists = os.path.exists(py_path)
        scraper_password = kodi.get_setting('scraper_password')
        if scraper_url and scraper_password:
            old_lm = None
            old_py = ''
            if exists:
                with open(py_path, 'r') as f:
                    old_py = f.read()
                    match = re.search('^#\s+Last-Modified:\s*(.*)', old_py)
                    if match:
                        old_lm = match.group(1).strip()

            new_lm, new_py = utils2.get_and_decrypt(scraper_url, scraper_password, old_lm)
            if new_py:
                logger.log('%s path: %s, new_py: %s, match: %s' % (filename, py_path, bool(new_py), new_py == old_py), log_utils.LOGDEBUG)
                if old_py != new_py:
                    with open(py_path, 'w') as f:
                        f.write('# Last-Modified: %s\n' % (new_lm))
                        f.write(new_py)
                    kodi.notify(msg=utils2.i18n('scraper_updated') + filename)
                        
    except Exception as e:
        logger.log('Failure during %s scraper update: %s' % (filename, e), log_utils.LOGWARNING)

def validate_xml(xml):
    try:
        # Basic XML structure validation
        assert '<settings version="1">' in xml
        assert '</settings>' in xml
        return True
    except AssertionError:
        logger.log('Invalid XML structure detected', log_utils.LOGERROR)
        return False

update_settings()
update_all_scrapers()
