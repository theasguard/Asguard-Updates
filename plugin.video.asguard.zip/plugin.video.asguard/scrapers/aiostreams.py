"""
    Asguard Addon
    Copyright (C) 2024
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import logging
import re
import json
import urllib.parse
import urllib.error
import urllib.request
import requests
from asguard_lib.utils2 import i18n
import xbmcgui
import kodi
import log_utils
from asguard_lib import scraper_utils, control
from asguard_lib.constants import FORCE_NO_MATCH, VIDEO_TYPES, QUALITIES
from . import scraper


try:
    import resolveurl
except ImportError:
    kodi.notify(msg=i18n('smu_failed'), duration=5000)
    
logger = log_utils.Logger.get_logger()

class Scraper(scraper.Scraper):
    base_url = 'https://aiostreams.elfhosted.com/manifest.json'
    movie_search_url = '/eyJhcGlLZXkiOiIiLCJvdmVycmlkZU5hbWUiOiIiLCJzdHJlYW1UeXBlcyI6W3sidXNlbmV0Ijp0cnVlfSx7ImRlYnJpZCI6dHJ1ZX0seyJ1bmtub3duIjp0cnVlfSx7InAycCI6dHJ1ZX0seyJsaXZlIjp0cnVlfV0sInJlc29sdXRpb25zIjpbeyIyMTYwcCI6dHJ1ZX0seyIxNDQwcCI6dHJ1ZX0seyIxMDgwcCI6dHJ1ZX0seyI3MjBwIjp0cnVlfSx7IjQ4MHAiOnRydWV9LHsiVW5rbm93biI6dHJ1ZX1dLCJxdWFsaXRpZXMiOlt7IkJsdVJheSBSRU1VWCI6dHJ1ZX0seyJCbHVSYXkiOnRydWV9LHsiV0VCLURMIjp0cnVlfSx7IldFQlJpcCI6dHJ1ZX0seyJIRFJpcCI6dHJ1ZX0seyJIQyBIRC1SaXAiOnRydWV9LHsiRFZEUmlwIjp0cnVlfSx7IkhEVFYiOnRydWV9LHsiQ0FNIjp0cnVlfSx7IlRTIjp0cnVlfSx7IlRDIjp0cnVlfSx7IlNDUiI6dHJ1ZX0seyJVbmtub3duIjp0cnVlfV0sInZpc3VhbFRhZ3MiOlt7IkhEUitEViI6dHJ1ZX0seyJIRFIxMCsiOnRydWV9LHsiRFYiOnRydWV9LHsiSERSMTAiOnRydWV9LHsiSERSIjp0cnVlfSx7IjEwYml0Ijp0cnVlfSx7IjNEIjp0cnVlfSx7IklNQVgiOnRydWV9LHsiQUkiOnRydWV9LHsiU0RSIjp0cnVlfV0sImF1ZGlvVGFncyI6W3siQXRtb3MiOnRydWV9LHsiREQrIjp0cnVlfSx7IkREIjp0cnVlfSx7IkRUUy1IRCBNQSI6dHJ1ZX0seyJEVFMtSEQiOnRydWV9LHsiRFRTIjp0cnVlfSx7IlRydWVIRCI6dHJ1ZX0seyI1LjEiOnRydWV9LHsiNy4xIjp0cnVlfSx7IkZMQUMiOnRydWV9LHsiQUFDIjp0cnVlfV0sImVuY29kZXMiOlt7IkFWMSI6dHJ1ZX0seyJIRVZDIjp0cnVlfSx7IkFWQyI6dHJ1ZX0seyJYdmlkIjp0cnVlfSx7IkRpdlgiOnRydWV9LHsiSC1PVSI6dHJ1ZX0seyJILVNCUyI6dHJ1ZX0seyJVbmtub3duIjp0cnVlfV0sInNvcnRCeSI6W3siY2FjaGVkIjp0cnVlLCJkaXJlY3Rpb24iOiJkZXNjIn0seyJyZXNvbHV0aW9uIjp0cnVlfSx7Imxhbmd1YWdlIjp0cnVlfSx7InNpemUiOnRydWUsImRpcmVjdGlvbiI6ImRlc2MifSx7InN0cmVhbVR5cGUiOmZhbHNlfSx7InZpc3VhbFRhZyI6ZmFsc2V9LHsic2VydmljZSI6ZmFsc2V9LHsiYXVkaW9UYWciOmZhbHNlfSx7ImVuY29kZSI6ZmFsc2V9LHsicXVhbGl0eSI6ZmFsc2V9LHsic2VlZGVycyI6ZmFsc2UsImRpcmVjdGlvbiI6ImRlc2MifSx7ImFkZG9uIjpmYWxzZX1dLCJvbmx5U2hvd0NhY2hlZFN0cmVhbXMiOmZhbHNlLCJwcmlvcml0aXNlZExhbmd1YWdlcyI6bnVsbCwiZXhjbHVkZWRMYW5ndWFnZXMiOm51bGwsIm1heE1vdmllU2l6ZSI6bnVsbCwibWluTW92aWVTaXplIjpudWxsLCJtYXhFcGlzb2RlU2l6ZSI6bnVsbCwibWluRXBpc29kZVNpemUiOm51bGwsImFkZG9uTmFtZUluRGVzY3JpcHRpb24iOmZhbHNlLCJjbGVhblJlc3VsdHMiOmZhbHNlLCJtYXhSZXN1bHRzUGVyUmVzb2x1dGlvbiI6bnVsbCwic3RyaWN0SW5jbHVkZUZpbHRlcnMiOm51bGwsImV4Y2x1ZGVGaWx0ZXJzIjpudWxsLCJmb3JtYXR0ZXIiOiJnZHJpdmUiLCJtZWRpYUZsb3dDb25maWciOnsibWVkaWFGbG93RW5hYmxlZCI6ZmFsc2UsInByb3h5VXJsIjoiIiwiYXBpUGFzc3dvcmQiOiIiLCJwdWJsaWNJcCI6IiIsInByb3hpZWRBZGRvbnMiOm51bGwsInByb3hpZWRTZXJ2aWNlcyI6bnVsbH0sImFkZG9ucyI6W3siaWQiOiJ0b3Jib3giLCJvcHRpb25zIjp7fX1dLCJzZXJ2aWNlcyI6W3sibmFtZSI6IlJlYWwgRGVicmlkIiwiaWQiOiJyZWFsZGVicmlkIiwiZW5hYmxlZCI6ZmFsc2UsImNyZWRlbnRpYWxzIjp7fX0seyJuYW1lIjoiQWxsIERlYnJpZCIsImlkIjoiYWxsZGVicmlkIiwiZW5hYmxlZCI6ZmFsc2UsImNyZWRlbnRpYWxzIjp7fX0seyJuYW1lIjoiUHJlbWl1bWl6ZSIsImlkIjoicHJlbWl1bWl6ZSIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6IkRlYnJpZCBMaW5rIiwiaWQiOiJkZWJyaWRsaW5rIiwiZW5hYmxlZCI6ZmFsc2UsImNyZWRlbnRpYWxzIjp7fX0seyJuYW1lIjoiVG9yYm94IiwiaWQiOiJ0b3Jib3giLCJlbmFibGVkIjp0cnVlLCJjcmVkZW50aWFscyI6eyJhcGlLZXkiOiJlODAwZWUyYi1kMmRmLTQ0MDYtOTk2MS1hNjdhMjRjNWM0MGUifX0seyJuYW1lIjoiT2ZmY2xvdWQiLCJpZCI6Im9mZmNsb3VkIiwiZW5hYmxlZCI6ZmFsc2UsImNyZWRlbnRpYWxzIjp7fX0seyJuYW1lIjoicHV0LmlvIiwiaWQiOiJwdXRpbyIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6IkVhc3luZXdzIiwiaWQiOiJlYXN5bmV3cyIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6IkVhc3lEZWJyaWQiLCJpZCI6ImVhc3lkZWJyaWQiLCJlbmFibGVkIjpmYWxzZSwiY3JlZGVudGlhbHMiOnt9fSx7Im5hbWUiOiJQaWtQYWsiLCJpZCI6InBpa3BhayIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6IlNlZWRyIiwiaWQiOiJzZWVkciIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6Ik9yaW9uIiwiaWQiOiJvcmlvbiIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319XX0=/stream/movie/%s.json'
    tv_search_url = '/eyJhcGlLZXkiOiIiLCJvdmVycmlkZU5hbWUiOiIiLCJzdHJlYW1UeXBlcyI6W3sidXNlbmV0Ijp0cnVlfSx7ImRlYnJpZCI6dHJ1ZX0seyJ1bmtub3duIjp0cnVlfSx7InAycCI6dHJ1ZX0seyJsaXZlIjp0cnVlfV0sInJlc29sdXRpb25zIjpbeyIyMTYwcCI6dHJ1ZX0seyIxNDQwcCI6dHJ1ZX0seyIxMDgwcCI6dHJ1ZX0seyI3MjBwIjp0cnVlfSx7IjQ4MHAiOnRydWV9LHsiVW5rbm93biI6dHJ1ZX1dLCJxdWFsaXRpZXMiOlt7IkJsdVJheSBSRU1VWCI6dHJ1ZX0seyJCbHVSYXkiOnRydWV9LHsiV0VCLURMIjp0cnVlfSx7IldFQlJpcCI6dHJ1ZX0seyJIRFJpcCI6dHJ1ZX0seyJIQyBIRC1SaXAiOnRydWV9LHsiRFZEUmlwIjp0cnVlfSx7IkhEVFYiOnRydWV9LHsiQ0FNIjp0cnVlfSx7IlRTIjp0cnVlfSx7IlRDIjp0cnVlfSx7IlNDUiI6dHJ1ZX0seyJVbmtub3duIjp0cnVlfV0sInZpc3VhbFRhZ3MiOlt7IkhEUitEViI6dHJ1ZX0seyJIRFIxMCsiOnRydWV9LHsiRFYiOnRydWV9LHsiSERSMTAiOnRydWV9LHsiSERSIjp0cnVlfSx7IjEwYml0Ijp0cnVlfSx7IjNEIjp0cnVlfSx7IklNQVgiOnRydWV9LHsiQUkiOnRydWV9LHsiU0RSIjp0cnVlfV0sImF1ZGlvVGFncyI6W3siQXRtb3MiOnRydWV9LHsiREQrIjp0cnVlfSx7IkREIjp0cnVlfSx7IkRUUy1IRCBNQSI6dHJ1ZX0seyJEVFMtSEQiOnRydWV9LHsiRFRTIjp0cnVlfSx7IlRydWVIRCI6dHJ1ZX0seyI1LjEiOnRydWV9LHsiNy4xIjp0cnVlfSx7IkZMQUMiOnRydWV9LHsiQUFDIjp0cnVlfV0sImVuY29kZXMiOlt7IkFWMSI6dHJ1ZX0seyJIRVZDIjp0cnVlfSx7IkFWQyI6dHJ1ZX0seyJYdmlkIjp0cnVlfSx7IkRpdlgiOnRydWV9LHsiSC1PVSI6dHJ1ZX0seyJILVNCUyI6dHJ1ZX0seyJVbmtub3duIjp0cnVlfV0sInNvcnRCeSI6W3siY2FjaGVkIjp0cnVlLCJkaXJlY3Rpb24iOiJkZXNjIn0seyJyZXNvbHV0aW9uIjp0cnVlfSx7Imxhbmd1YWdlIjp0cnVlfSx7InNpemUiOnRydWUsImRpcmVjdGlvbiI6ImRlc2MifSx7InN0cmVhbVR5cGUiOmZhbHNlfSx7InZpc3VhbFRhZyI6ZmFsc2V9LHsic2VydmljZSI6ZmFsc2V9LHsiYXVkaW9UYWciOmZhbHNlfSx7ImVuY29kZSI6ZmFsc2V9LHsicXVhbGl0eSI6ZmFsc2V9LHsic2VlZGVycyI6ZmFsc2UsImRpcmVjdGlvbiI6ImRlc2MifSx7ImFkZG9uIjpmYWxzZX1dLCJvbmx5U2hvd0NhY2hlZFN0cmVhbXMiOmZhbHNlLCJwcmlvcml0aXNlZExhbmd1YWdlcyI6bnVsbCwiZXhjbHVkZWRMYW5ndWFnZXMiOm51bGwsIm1heE1vdmllU2l6ZSI6bnVsbCwibWluTW92aWVTaXplIjpudWxsLCJtYXhFcGlzb2RlU2l6ZSI6bnVsbCwibWluRXBpc29kZVNpemUiOm51bGwsImFkZG9uTmFtZUluRGVzY3JpcHRpb24iOmZhbHNlLCJjbGVhblJlc3VsdHMiOmZhbHNlLCJtYXhSZXN1bHRzUGVyUmVzb2x1dGlvbiI6bnVsbCwic3RyaWN0SW5jbHVkZUZpbHRlcnMiOm51bGwsImV4Y2x1ZGVGaWx0ZXJzIjpudWxsLCJmb3JtYXR0ZXIiOiJnZHJpdmUiLCJtZWRpYUZsb3dDb25maWciOnsibWVkaWFGbG93RW5hYmxlZCI6ZmFsc2UsInByb3h5VXJsIjoiIiwiYXBpUGFzc3dvcmQiOiIiLCJwdWJsaWNJcCI6IiIsInByb3hpZWRBZGRvbnMiOm51bGwsInByb3hpZWRTZXJ2aWNlcyI6bnVsbH0sImFkZG9ucyI6W3siaWQiOiJ0b3Jib3giLCJvcHRpb25zIjp7fX1dLCJzZXJ2aWNlcyI6W3sibmFtZSI6IlJlYWwgRGVicmlkIiwiaWQiOiJyZWFsZGVicmlkIiwiZW5hYmxlZCI6ZmFsc2UsImNyZWRlbnRpYWxzIjp7fX0seyJuYW1lIjoiQWxsIERlYnJpZCIsImlkIjoiYWxsZGVicmlkIiwiZW5hYmxlZCI6ZmFsc2UsImNyZWRlbnRpYWxzIjp7fX0seyJuYW1lIjoiUHJlbWl1bWl6ZSIsImlkIjoicHJlbWl1bWl6ZSIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6IkRlYnJpZCBMaW5rIiwiaWQiOiJkZWJyaWRsaW5rIiwiZW5hYmxlZCI6ZmFsc2UsImNyZWRlbnRpYWxzIjp7fX0seyJuYW1lIjoiVG9yYm94IiwiaWQiOiJ0b3Jib3giLCJlbmFibGVkIjp0cnVlLCJjcmVkZW50aWFscyI6eyJhcGlLZXkiOiJlODAwZWUyYi1kMmRmLTQ0MDYtOTk2MS1hNjdhMjRjNWM0MGUifX0seyJuYW1lIjoiT2ZmY2xvdWQiLCJpZCI6Im9mZmNsb3VkIiwiZW5hYmxlZCI6ZmFsc2UsImNyZWRlbnRpYWxzIjp7fX0seyJuYW1lIjoicHV0LmlvIiwiaWQiOiJwdXRpbyIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6IkVhc3luZXdzIiwiaWQiOiJlYXN5bmV3cyIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6IkVhc3lEZWJyaWQiLCJpZCI6ImVhc3lkZWJyaWQiLCJlbmFibGVkIjpmYWxzZSwiY3JlZGVudGlhbHMiOnt9fSx7Im5hbWUiOiJQaWtQYWsiLCJpZCI6InBpa3BhayIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6IlNlZWRyIiwiaWQiOiJzZWVkciIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319LHsibmFtZSI6Ik9yaW9uIiwiaWQiOiJvcmlvbiIsImVuYWJsZWQiOmZhbHNlLCJjcmVkZW50aWFscyI6e319XX0=/stream/series/%s:%s:%s.json'
    debrid_resolvers = resolveurl

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.min_seeders = 0
        self.bypass_filter = control.getSetting('Aiostreams-bypass_filter') == 'true'
        self.api_key = control.getSetting('Aiostreams-api_key')  # Get API key from settings
        self._set_apikeys()

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.MOVIE, VIDEO_TYPES.TVSHOW, VIDEO_TYPES.EPISODE])

    @classmethod
    def get_name(cls):
        return 'AioStreams'
    
    def resolve_link(self, link):
        logging.debug("Resolving link: %s", link)
        return link

    def _set_apikeys(self):
        self.pm_apikey = kodi.get_setting('premiumize.apikey')
        self.rd_apikey = kodi.get_setting('realdebrid.apikey')
        self.ad_apikey = kodi.get_setting('alldebrid_api_key')

    def get_sources(self, video):
        from asguard_lib.trakt_api import Trakt_API
        sources = []
        trakt_id = video.trakt_id

        try:
            if video.video_type == VIDEO_TYPES.MOVIE:
                if not hasattr(video, 'imdb_id'):
                    details = Trakt_API().get_movie_details(trakt_id)
                    video.imdb_id = details['ids']['imdb']
                search_url = self.movie_search_url % (video.imdb_id)
                logger.log('Searching for movie: %s' % search_url, log_utils.LOGDEBUG)
            else:
                if not all(hasattr(video, attr) for attr in ['imdb_id', 'season', 'episode']):
                    details = Trakt_API().get_show_details(trakt_id)
                    video.imdb_id = details['ids']['imdb']
                    video.season = video.season
                    video.episode = video.episode
                search_url = self.tv_search_url % (video.imdb_id, video.season, video.episode)
                logger.log('Searching for episode: %s' % search_url, log_utils.LOGDEBUG)

            url = urllib.parse.urljoin(self.base_url, search_url)
            response = self._http_get(url, cache_limit=1, require_debrid=True, allow_redirect=True)
            logger.log('AioStreams Response: %s' % response, log_utils.LOGDEBUG)
            if not response or response == FORCE_NO_MATCH:
                return sources

            try:
                files = json.loads(response).get('streams', [])
                logger.log('AioStreams Found %d files' % len(files), log_utils.LOGDEBUG)
            except json.JSONDecodeError as e:
                logger.log('Failed to parse JSON response from AioStreams: %s' % str(e), log_utils.LOGERROR)
                return sources

            for file in files:
                try:
                    hash = file['url']
                    logger.log('AioStreams Found file: %s' % hash, log_utils.LOGDEBUG)
                    name = file['description']
                    # Handle variable number of description lines
                    name_part = name.split('\n')
                    size_line = next((line for line in name_part if '📦' in line), '')
                    name_part = scraper_utils.cleanse_title(name_part[-1].strip())  # Get last line and clean it
                    url = hash
                    logger.log('AioStreams Found file: %s' % url, log_utils.LOGDEBUG)

                    quality= scraper_utils.get_tor_quality(name)
                    info = []
                    size_match = re.search(r'📦\s*([\d.]+)\s*(GiB|MiB)', size_line)
                    size = 0
                    if size_match:
                        size_value = float(size_match.group(1))
                        size_unit = size_match.group(2)
                        if size_unit == 'GiB':
                            size = size_value * 1024  # Convert GiB to MB
                        else:
                            size = size_value  # MiB is already MB

                    info = ' | '.join(info)
                    label = f"{name_part} | {size}MB"
                    sources.append({
                        'class': self,
                        'host': 'magnet',
                        'label': label,
                        'multi-part': False,
                        'hash': hash,
                        'name': name_part,
                        'quality': quality,
                        'size': size,
                        'language': 'en',
                        'url': url,
                        'info': info,
                        'direct': False,
                        'debridonly': True
                    })
                except Exception as e:
                    logger.log('Error processing AioStreams source: %s' % str(e), log_utils.LOGERROR)
                    continue
                logger.log('Found source: %s' % sources, log_utils.LOGDEBUG)

        except AttributeError as e:
            logger.log('AttributeError: %s' % str(e), log_utils.LOGERROR)
        except Exception as e:
            logger.log('Unexpected error: %s' % str(e), log_utils.LOGERROR)

        return sources

    def _http_get(self, url, data=None, retry=True, allow_redirect=True, cache_limit=8, require_debrid=True):
        if require_debrid:
            if Scraper.debrid_resolvers is None:
                Scraper.debrid_resolvers = [resolver for resolver in resolveurl.choose_source(url) if resolver.isUniversal()]
            if not Scraper.debrid_resolvers:
                logger.log('%s requires debrid: %s' % (self.__module__, Scraper.debrid_resolvers), log_utils.LOGDEBUG)
                return ''
        try:
            headers = {'User-Agent': scraper_utils.get_ua()}
            req = urllib.request.Request(url, data=data, headers=headers)
            logging.debug("Retrieved req: %s", req)
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return response.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            logger.log(f'HTTP Error: {e.code} - {url}', log_utils.LOGWARNING)
        except urllib.error.URLError as e:
            logger.log(f'URL Error: {e.reason} - {url}', log_utils.LOGWARNING)
        return ''

