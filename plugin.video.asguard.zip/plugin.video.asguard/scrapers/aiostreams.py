"""
    Asguard Addon
    Copyright (C) 2024
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import json
import re
import urllib.error
import urllib.parse
import urllib.request

import requests

from asguard_lib import control, scraper_utils
from asguard_lib.constants import FORCE_NO_MATCH, QUALITIES, VIDEO_TYPES
from asguard_lib.utils2 import i18n
import kodi
import log_utils
import xbmcgui

from . import scraper

try:
    import resolveurl
except ImportError:
    kodi.notify(msg=i18n('smu_failed'), duration=5000)
    
logger = log_utils.Logger.get_logger()


BASE_URL = 'https://aiostreams.elfhosted.com/'

class Scraper(scraper.Scraper):
    base_url = BASE_URL
    debrid_resolvers = resolveurl

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.base_url = kodi.get_setting(f'{self.get_name()}-base_url')
        self.bypass_filter = kodi.get_setting('AioStreams-bypass_filter') == 'true'
        self.process_p2p_hashes = kodi.get_setting('AioStreams-process_p2p_hashes') == 'true'
        
        logger.log('AIOStreams: Initializing scraper', log_utils.LOGDEBUG)
        self._set_apikeys()
        
        # Get custom configuration URL or use default
        custom_config = kodi.get_setting('AioStreams-custom_config')
        if custom_config and custom_config.strip():
            # Extract configuration from custom URL
            config_params = self._extract_config_from_url(custom_config.strip())
            logger.log('AIOStreams: Using custom configuration from user setting', log_utils.LOGDEBUG)
        else:
            # Use default configuration
            config_params = 'a906c76e-1855-4544-a697-77034efeca74/eyJpdiI6InNGczdWQWk4bEdUTFBBM0lRSXZRR2c9PSIsImVuY3J5cHRlZCI6Iis0aStlb2ptdHAyM3dsSGp6TEhyMUtRejhvdW9XazJxRlFFTnM2T3FFY0k9IiwidHlwZSI6ImFpb0VuY3J5cHQifQ'
            logger.log('AIOStreams: Using default configuration (limited functionality)', log_utils.LOGWARNING)
            logger.log('AIOStreams: For full features, visit https://aiostreams.elfhosted.com/stremio/configure to generate your custom configuration', log_utils.LOGWARNING)
        
        self.movie_search_url = f'/stremio/{config_params}/stream/movie/%s.json'
        self.tv_search_url = f'/stremio/{config_params}/stream/series/%s:%s:%s.json'
        
        logger.log('AIOStreams: Scraper initialized successfully', log_utils.LOGDEBUG)

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.MOVIE, VIDEO_TYPES.TVSHOW, VIDEO_TYPES.EPISODE])

    @classmethod
    def get_name(cls):
        return 'AioStreams'
    
    @classmethod
    def get_settings(cls):
        settings = super(cls, cls).get_settings()
        name = cls.get_name()
        parent_id = f"{name}-enable"
        
        settings.extend([
            f'''\t\t<setting id="{name}-bypass_filter" type="boolean" label="40483" help="">
\t\t\t<level>0</level>
\t\t\t<default>false</default>
\t\t\t<dependencies>
\t\t\t\t<dependency type="visible">
\t\t\t\t\t<condition operator="is" setting="{parent_id}">true</condition>
\t\t\t\t</dependency>
\t\t\t</dependencies>
\t\t\t<control type="toggle"/>
\t\t</setting>''',
            f'''\t\t<setting id="{name}-custom_config" type="string" label="40527" help="Leave empty to use default config. Visit aiostreams.elfhosted.com/stremio/configure to generate your own configuration with debrid services and filters.">
\t\t\t<level>0</level>
\t\t\t<default></default>
\t\t\t<dependencies>
\t\t\t\t<dependency type="visible">
\t\t\t\t\t<condition operator="is" setting="{parent_id}">true</condition>
\t\t\t\t</dependency>
\t\t\t</dependencies>
\t\t\t<constraints>
\t\t\t\t<allowempty>true</allowempty>
\t\t\t</constraints>
\t\t\t<control type="edit" format="string">
\t\t\t\t<heading>Custom Configuration URL</heading>
\t\t\t</control>
\t\t</setting>''',
            f'''\t\t<setting id="{name}-process_p2p_hashes" type="boolean" label="40482" help="Enable processing of P2P torrent hashes using your debrid service. This can provide more streams but may be slower.">
\t\t\t<level>0</level>
\t\t\t<default>false</default>
\t\t\t<dependencies>
\t\t\t\t<dependency type="visible">
\t\t\t\t\t<condition operator="is" setting="{parent_id}">true</condition>
\t\t\t\t</dependency>
\t\t\t</dependencies>
\t\t\t<control type="toggle"/>
\t\t</setting>'''
        ])
        
        return settings
    
    def resolve_link(self, link):
        return link

    def _set_apikeys(self):
        self.pm_apikey = kodi.get_setting('premiumize.apikey')
        self.rd_apikey = kodi.get_setting('realdebrid.apikey')
        self.ad_apikey = kodi.get_setting('alldebrid_api_key')
        self.tb_apikey = kodi.get_setting('torbox.apikey')
        self.dl_apikey = kodi.get_setting('debridlink.apikey')
    
    def _extract_config_from_url(self, url):
        """Extract configuration parameters from AIOStreams URL"""
        try:
            logger.log('AIOStreams: Extracting config from URL: %s' % url[:100] + '...', log_utils.LOGDEBUG)
            
            # Handle different URL formats:
            # 1. Full manifest URL: https://aiostreams.elfhosted.com/[config]/manifest.json
            # 2. Stream URL: https://aiostreams.elfhosted.com/stremio/[config]/stream/...
            # 3. Just the config part: [config]
            
            if '/manifest.json' in url:
                # Extract config from manifest URL
                config_part = url.split('/')[-2]  # Get part before manifest.json
                logger.log('AIOStreams: Extracted config from manifest URL', log_utils.LOGDEBUG)
            elif '/stremio/' in url:
                # Extract config from stremio URL
                stremio_part = url.split('/stremio/')[1]
                config_part = stremio_part.split('/')[0]
                logger.log('AIOStreams: Extracted config from stremio URL', log_utils.LOGDEBUG)
            elif url.startswith('http'):
                # Try to extract from any HTTP URL by finding base64-like patterns
                parts = url.split('/')
                for part in parts:
                    if len(part) > 50 and self._looks_like_base64(part):
                        config_part = part
                        logger.log('AIOStreams: Found config pattern in URL', log_utils.LOGDEBUG)
                        break
                else:
                    logger.log('AIOStreams: Could not find valid config in URL', log_utils.LOGWARNING)
                    return self._get_fallback_config()
            else:
                # Assume it's just the config part itself
                config_part = url.strip()
                logger.log('AIOStreams: Using raw config parameter', log_utils.LOGDEBUG)
            
            # Validate the extracted config
            if self._validate_config(config_part):
                logger.log('AIOStreams: Configuration validated successfully', log_utils.LOGDEBUG)
                return config_part
            else:
                logger.log('AIOStreams: Invalid configuration format, using fallback', log_utils.LOGWARNING)
                return self._get_fallback_config()
                
        except Exception as e:
            logger.log('AIOStreams: Error extracting config from URL: %s' % str(e), log_utils.LOGERROR)
            return self._get_fallback_config()
    
    def _looks_like_base64(self, text):
        """Check if text looks like base64 encoded data"""
        try:
            import base64
            if len(text) < 20:  # Too short
                return False
            # Check if it's valid base64
            base64.b64decode(text + '==')  # Add padding just in case
            return True
        except:
            return False
    
    def _validate_config(self, config):
        """Validate if config looks like a valid AIOStreams configuration"""
        try:
            # Should contain either:
            # 1. UUID/base64 format (like current): uuid/base64data
            # 2. Just base64 data
            
            if '/' in config:
                parts = config.split('/')
                if len(parts) >= 2:
                    uuid_part = parts[0]
                    base64_part = parts[1]
                    # Basic UUID format check (loose)
                    if len(uuid_part) >= 30 and '-' in uuid_part:
                        return self._looks_like_base64(base64_part)
            else:
                # Just base64 data
                return self._looks_like_base64(config)
            
            return False
        except:
            return False
    
    def _get_fallback_config(self):
        """Get fallback configuration with user's debrid keys if available"""
        logger.log('AIOStreams: Generating fallback configuration', log_utils.LOGDEBUG)
        
        # Try to provide guidance to user
        if any([self.rd_apikey, self.pm_apikey, self.ad_apikey, self.tb_apikey, self.dl_apikey]):
            logger.log('AIOStreams: Debrid API keys detected. Generate custom config at https://aiostreams.elfhosted.com/stremio/configure for full functionality', log_utils.LOGWARNING)
        else:
            logger.log('AIOStreams: No debrid API keys found. Add your keys in Asguard Settings → Debrid Services, then visit https://aiostreams.elfhosted.com/stremio/configure', log_utils.LOGWARNING)
        
        # Return default config
        return 'a906c76e-1855-4544-a697-77034efeca74/eyJpdiI6InNGczdWQWk4bEdUTFBBM0lRSXZRR2c9PSIsImVuY3J5cHRlZCI6Iis0aStlb2ptdHAyM3dsSGp6TEhyMUtRejhvdW9XazJxRlFFTnM2T3FFY0k9IiwidHlwZSI6ImFpb0VuY3J5cHQifQ'
    
    def _convert_hash_to_url(self, info_hash, filename, file_size=0):
        """Convert P2P torrent hash to direct streaming URL using debrid services"""
        try:
            logger.log('AIOStreams: Converting hash to URL: %s' % info_hash[:16] + '...', log_utils.LOGDEBUG)
            
            # Try debrid services in priority order
            if self.tb_apikey:
                url = self._torbox_hash_to_url(info_hash, filename, file_size)
                if url:
                    return url
            
            if self.rd_apikey:
                url = self._realdebrid_hash_to_url(info_hash, filename, file_size)
                if url:
                    return url
                    
            if self.ad_apikey:
                url = self._alldebrid_hash_to_url(info_hash, filename, file_size)
                if url:
                    return url
                    
            if self.pm_apikey:
                url = self._premiumize_hash_to_url(info_hash, filename, file_size)
                if url:
                    return url
                    
            if self.dl_apikey:
                url = self._debridlink_hash_to_url(info_hash, filename, file_size)
                if url:
                    return url
            
            logger.log('AIOStreams: No debrid service could convert hash: %s' % info_hash[:16], log_utils.LOGDEBUG)
            return None
            
        except Exception as e:
            logger.log('AIOStreams: Error converting hash to URL: %s' % str(e), log_utils.LOGWARNING)
            return None
    
    def _torbox_hash_to_url(self, info_hash, filename, file_size=0):
        """Convert hash to URL using TorBox API (Updated for current API)"""
        try:
            # Current TorBox API endpoint (2024 format based on Postman collection)
            check_url = 'https://api.torbox.app/v1/api/torrents/checkcached'
            headers = {
                'Authorization': f'Bearer {self.tb_apikey}'
            }
            
            # Current API uses query parameters, not JSON body
            params = {
                'hash': info_hash,
                'format': 'object'
            }
            
            response = requests.get(check_url, headers=headers, params=params, timeout=10)
            logger.log('AIOStreams: TorBox response: %s' % response.status_code, log_utils.LOGDEBUG)
            
            if response.status_code == 200:
                result = response.json()
                # Current API response format: {"success": true, "error": null, "detail": "...", "data": {...}}
                if result.get('success'):
                    cached_data = result.get('data', {})
                    
                    # Check if hash is in cached data
                    if info_hash in cached_data:
                        torrent_info = cached_data[info_hash]
                        
                        # Check if torrent is available/cached
                        if torrent_info.get('cached', False) or torrent_info.get('available', False):
                            # Modern TorBox API workflow (2024):
                            # 1. Create torrent from magnet/hash
                            # 2. Get torrent ID  
                            # 3. Request download link
                            
                            magnet_url = f'magnet:?xt=urn:btih:{info_hash}'
                            
                            # Try to create torrent and get direct link
                            create_url = 'https://api.torbox.app/v1/api/torrents/createtorrent'
                            create_data = {
                                'magnet': magnet_url,
                                'seed': 1  # Enable seeding
                            }
                            
                            create_response = requests.post(create_url, headers=headers, data=create_data, timeout=15)
                            
                            if create_response.status_code == 200:
                                create_result = create_response.json()
                                if create_result.get('success') and create_result.get('data'):
                                    torrent_id = create_result['data'].get('torrent_id')
                                    
                                    if torrent_id:
                                        # Get download link for the torrent
                                        download_url = f'https://api.torbox.app/v1/api/torrents/requestdl'
                                        download_params = {
                                            'torrent_id': torrent_id,
                                            'file_id': 1  # Default to first file, could be improved
                                        }
                                        
                                        stream_url = f'{download_url}?torrent_id={torrent_id}&file_id=1&token={self.tb_apikey}'
                                        logger.log('AIOStreams: TorBox torrent created and stream URL generated', log_utils.LOGDEBUG)
                                        return stream_url
                            
                            # Fallback: return magnet URL for external handling
                            logger.log('AIOStreams: TorBox cached but could not create direct stream, returning magnet', log_utils.LOGDEBUG)
                            return magnet_url
                        else:
                            logger.log('AIOStreams: TorBox torrent not cached: %s' % info_hash[:16], log_utils.LOGDEBUG)
                    else:
                        logger.log('AIOStreams: TorBox hash not found in response: %s' % info_hash[:16], log_utils.LOGDEBUG)
                else:
                    # Empty data means no cached torrents found
                    logger.log('AIOStreams: TorBox no cached data for hash: %s' % info_hash[:16], log_utils.LOGDEBUG)
            else:
                logger.log('AIOStreams: TorBox API error: %s - %s' % (response.status_code, response.text[:200]), log_utils.LOGDEBUG)
                
        except Exception as e:
            logger.log('AIOStreams: TorBox hash conversion error: %s' % str(e), log_utils.LOGDEBUG)
            
        return None
    
    def _realdebrid_hash_to_url(self, info_hash, filename, file_size=0):
        """Convert hash to URL using Real-Debrid API"""
        try:
            # Check if torrent is cached
            check_url = 'https://api.real-debrid.com/rest/1.0/torrents/instantAvailability/' + info_hash
            headers = {'Authorization': f'Bearer {self.rd_apikey}'}
            
            response = requests.get(check_url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                if result.get(info_hash):
                    # Torrent is available
                    availability = result[info_hash]
                    if 'rd' in availability:
                        rd_files = availability['rd']
                        if rd_files:
                            # Find best matching file
                            best_file = None
                            for file_group in rd_files:
                                for file_id, file_info in file_group.items():
                                    file_name = file_info.get('filename', '')
                                    if filename.lower() in file_name.lower() or file_name.lower() in filename.lower():
                                        best_file = {'id': file_id, 'info': file_info}
                                        break
                                if best_file:
                                    break
                            
                            if not best_file and rd_files:
                                # Use first available file
                                first_group = rd_files[0]
                                first_id = list(first_group.keys())[0]
                                best_file = {'id': first_id, 'info': first_group[first_id]}
                            
                            if best_file:
                                # Create magnet URL for Real-Debrid
                                magnet_url = f'magnet:?xt=urn:btih:{info_hash}'
                                # Real-Debrid will need to add the torrent first, then get download link
                                # For now, return a placeholder that indicates RD processing needed
                                rd_url = f'https://real-debrid.com/magnet/{info_hash}#{best_file["id"]}'
                                logger.log('AIOStreams: Real-Debrid cached torrent found', log_utils.LOGDEBUG)
                                return rd_url
                else:
                    logger.log('AIOStreams: Real-Debrid torrent not cached: %s' % info_hash[:16], log_utils.LOGDEBUG)
            else:
                logger.log('AIOStreams: Real-Debrid API error: %s' % response.status_code, log_utils.LOGDEBUG)
                
        except Exception as e:
            logger.log('AIOStreams: Real-Debrid hash conversion error: %s' % str(e), log_utils.LOGDEBUG)
            
        return None
    
    def _alldebrid_hash_to_url(self, info_hash, filename, file_size=0):
        """Convert hash to URL using AllDebrid API"""
        try:
            # Check if torrent is cached
            check_url = 'https://api.alldebrid.com/v4/magnet/instant'
            params = {'agent': 'Asguard', 'apikey': self.ad_apikey, 'magnets[]': f'magnet:?xt=urn:btih:{info_hash}'}
            
            response = requests.get(check_url, params=params, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('status') == 'success':
                    magnets = result.get('data', {}).get('magnets', [])
                    if magnets:
                        magnet_info = magnets[0]
                        if magnet_info.get('instant', False):
                            # Torrent is cached
                            files = magnet_info.get('files', [])
                            if files:
                                # Find best matching file
                                best_file = None
                                for file_info in files:
                                    file_name = file_info.get('n', '')
                                    if filename.lower() in file_name.lower() or file_name.lower() in filename.lower():
                                        best_file = file_info
                                        break
                                
                                if not best_file:
                                    # Use first video file
                                    video_extensions = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm']
                                    for file_info in files:
                                        file_name = file_info.get('n', '')
                                        if any(ext in file_name.lower() for ext in video_extensions):
                                            best_file = file_info
                                            break
                                
                                if best_file:
                                    # AllDebrid streaming URL format
                                    ad_url = f'https://alldebrid.com/magnet/{info_hash}#{best_file.get("e", "")}'
                                    logger.log('AIOStreams: AllDebrid cached torrent found', log_utils.LOGDEBUG)
                                    return ad_url
                        else:
                            logger.log('AIOStreams: AllDebrid torrent not cached: %s' % info_hash[:16], log_utils.LOGDEBUG)
                else:
                    logger.log('AIOStreams: AllDebrid API error: %s' % result.get('error', 'Unknown'), log_utils.LOGDEBUG)
            else:
                logger.log('AIOStreams: AllDebrid HTTP error: %s' % response.status_code, log_utils.LOGDEBUG)
                
        except Exception as e:
            logger.log('AIOStreams: AllDebrid hash conversion error: %s' % str(e), log_utils.LOGDEBUG)
            
        return None
    
    def _premiumize_hash_to_url(self, info_hash, filename, file_size=0):
        """Convert hash to URL using Premiumize API"""
        try:
            # Check if torrent is cached
            check_url = 'https://api.premiumize.me/pm-api/v1.php'
            params = {
                'method': 'directdl',
                'params[src]': f'magnet:?xt=urn:btih:{info_hash}',
                'apikey': self.pm_apikey
            }
            
            response = requests.get(check_url, params=params, timeout=10)
            
            if response.status_code == 200:
                result = response.json()
                if result.get('status') == 'success':
                    # Torrent is cached and ready
                    content = result.get('result', {})
                    if content.get('link'):
                        pm_url = content['link']
                        logger.log('AIOStreams: Premiumize cached torrent found', log_utils.LOGDEBUG)
                        return pm_url
                    elif content.get('content'):
                        # Multiple files - find best match
                        files = content['content']
                        best_file = None
                        for file_info in files:
                            file_name = file_info.get('path', '')
                            if filename.lower() in file_name.lower() or file_name.lower() in filename.lower():
                                best_file = file_info
                                break
                        
                        if not best_file and files:
                            # Use first video file
                            video_extensions = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm']
                            for file_info in files:
                                file_name = file_info.get('path', '')
                                if any(ext in file_name.lower() for ext in video_extensions):
                                    best_file = file_info
                                    break
                        
                        if best_file and best_file.get('link'):
                            pm_url = best_file['link']
                            logger.log('AIOStreams: Premiumize multi-file cached torrent found', log_utils.LOGDEBUG)
                            return pm_url
                else:
                    logger.log('AIOStreams: Premiumize torrent not cached: %s' % info_hash[:16], log_utils.LOGDEBUG)
            else:
                logger.log('AIOStreams: Premiumize HTTP error: %s' % response.status_code, log_utils.LOGDEBUG)
                
        except Exception as e:
            logger.log('AIOStreams: Premiumize hash conversion error: %s' % str(e), log_utils.LOGDEBUG)
            
        return None
    
    def _debridlink_hash_to_url(self, info_hash, filename, file_size=0):
        """Convert hash to URL using DebridLink API"""
        try:
            # DebridLink doesn't have instant availability check, so we'll try to add it
            # This is a simplified implementation - in practice, you'd want to check cache first
            magnet_url = f'magnet:?xt=urn:btih:{info_hash}'
            
            # For now, return a placeholder that indicates DebridLink processing needed
            dl_url = f'https://debrid-link.fr/magnet/{info_hash}'
            logger.log('AIOStreams: DebridLink hash prepared for processing', log_utils.LOGDEBUG)
            return dl_url
                
        except Exception as e:
            logger.log('AIOStreams: DebridLink hash conversion error: %s' % str(e), log_utils.LOGDEBUG)
            
        return None
    
    def _get_debrid_indicator(self):
        """Get indicator for which debrid service would handle streams"""
        # Return the first available debrid service (matches priority in _convert_hash_to_url)
        if self.tb_apikey:
            return "TB"  # TorBox
        elif self.rd_apikey:
            return "RD"  # Real-Debrid
        elif self.ad_apikey:
            return "AD"  # AllDebrid
        elif self.pm_apikey:
            return "PM"  # Premiumize
        elif self.dl_apikey:
            return "DL"  # DebridLink
        else:
            return "DB"  # Generic Debrid (no specific service configured)
    
    def get_sources(self, video):
        sources = []

        try:
            logger.log('AIOStreams: Starting get_sources for video type: %s' % video.video_type, log_utils.LOGDEBUG)
            
            # Use centralized IMDB ID retrieval from base class
            imdb_id = self.get_imdb_id(video)
            if not imdb_id:
                logger.log('AIOStreams: No IMDB ID found for trakt_id: %s' % video.trakt_id, log_utils.LOGWARNING)
                return sources

            logger.log('AIOStreams: Found IMDB ID: %s' % imdb_id, log_utils.LOGDEBUG)

            if video.video_type == VIDEO_TYPES.MOVIE:
                search_url = self.movie_search_url % imdb_id
                logger.log('AIOStreams: Searching for movie: %s' % imdb_id, log_utils.LOGDEBUG)
            elif video.video_type == VIDEO_TYPES.EPISODE:
                search_url = self.tv_search_url % (imdb_id, video.season, video.episode)
                logger.log('AIOStreams: Searching for episode: %s S%sE%s' % (imdb_id, video.season, video.episode), log_utils.LOGDEBUG)
            else:
                logger.log('AIOStreams: Unsupported video type: %s' % video.video_type, log_utils.LOGWARNING)
                return sources

            url = urllib.parse.urljoin(self.base_url, search_url)
            logger.log('AIOStreams: Request URL: %s' % url, log_utils.LOGDEBUG)
            
            response = self._http_get(url, cache_limit=1, require_debrid=True)
            if not response or response == FORCE_NO_MATCH:
                logger.log('AIOStreams: No response from server for URL: %s' % url, log_utils.LOGWARNING)
                return sources
            
            logger.log('AIOStreams: Received response length: %d characters' % len(response), log_utils.LOGDEBUG)

            try:
                data = json.loads(response)
                files = data.get('streams', [])
                logger.log('AIOStreams: Found %d streams in response' % len(files), log_utils.LOGDEBUG)
                
                if not files:
                    logger.log('AIOStreams: No streams found. Response keys: %s' % list(data.keys()), log_utils.LOGDEBUG)
                    if 'error' in data:
                        logger.log('AIOStreams: API error: %s' % data['error'], log_utils.LOGWARNING)
                    elif 'message' in data:
                        logger.log('AIOStreams: API message: %s' % data['message'], log_utils.LOGWARNING)
                        
            except json.JSONDecodeError as e:
                logger.log('AIOStreams: Failed to parse JSON response: %s' % str(e), log_utils.LOGERROR)
                logger.log('AIOStreams: Response content: %s' % response[:500], log_utils.LOGDEBUG)
                return sources

            for file in files:
                try:
                    hash = file.get('url', '')
                    
                    # Handle P2P streams (torrent hashes without URLs)
                    if not hash and self.process_p2p_hashes:
                        info_hash = file.get('infoHash')
                        if info_hash:
                            stream_name = file.get('name', 'Unknown')
                            stream_data = file.get('streamData', {})
                            
                            # Only process P2P type streams
                            if stream_data.get('type') == 'p2p':
                                logger.log('AIOStreams: Processing P2P hash: %s for stream: %s' % (info_hash[:16], stream_name), log_utils.LOGDEBUG)
                                
                                # Extract filename for better matching
                                filename = ''
                                if 'behaviorHints' in file and 'filename' in file['behaviorHints']:
                                    filename = file['behaviorHints']['filename']
                                elif 'streamData' in file and 'filename' in file['streamData']:
                                    filename = file['streamData']['filename']
                                else:
                                    # Try to extract from description
                                    desc_lines = file.get('description', '').split('\n')
                                    for line in desc_lines:
                                        if line.strip() and '💾' not in line and not line.endswith('Audio'):
                                            filename = line.strip()
                                            break
                                
                                # Get file size for API calls
                                file_size = stream_data.get('size', 0)
                                magnet_url = f'magnet:?xt=urn:btih:{info_hash}'
                                # Try to convert hash to URL
                                converted_url = magnet_url
                                if converted_url:
                                    hash = converted_url
                                    logger.log('AIOStreams: Successfully converted P2P hash to URL: %s' % hash[:60] + '...', log_utils.LOGDEBUG)
                                else:
                                    logger.log('AIOStreams: Could not convert P2P hash to URL: %s' % info_hash[:16], log_utils.LOGDEBUG)
                                    continue
                            else:
                                logger.log('AIOStreams: Skipping non-P2P stream without URL - Name: %s' % stream_name, log_utils.LOGDEBUG)
                                continue
                        else:
                            stream_name = file.get('name', 'Unknown')
                            stream_desc = file.get('description', 'No description')[:100]
                            logger.log('AIOStreams: Skipping stream without URL or hash - Name: %s, Description: %s...' % (stream_name, stream_desc), log_utils.LOGDEBUG)
                            continue
                    elif not magnet_url:
                        # P2P processing disabled or no hash available
                        stream_name = file.get('name', 'Unknown')
                        stream_desc = file.get('description', 'No description')[:100]
                        if file.get('infoHash') and file.get('streamData', {}).get('type') == 'p2p':
                            logger.log('AIOStreams: Skipping P2P stream (processing disabled) - Name: %s' % stream_name, log_utils.LOGDEBUG)
                        else:
                            logger.log('AIOStreams: Skipping stream without URL - Name: %s, Description: %s...' % (stream_name, stream_desc), log_utils.LOGDEBUG)
                        continue
                        
                    logger.log('AIOStreams: Processing stream: %s' % hash[:100] + '...', log_utils.LOGDEBUG)
                    name = file.get('description', file.get('title', 'Unknown'))
                    
                    # Extract filename using the proper hierarchy
                    name_part = ''
                    
                    # Method 1: behaviorHints.filename (preferred)
                    if 'behaviorHints' in file and 'filename' in file['behaviorHints']:
                        name_part = file['behaviorHints']['filename'].strip()
                        logger.log('AioStreams: Using behaviorHints filename: %s' % name_part, log_utils.LOGDEBUG)
                    # Method 2: streamData.filename (fallback) 
                    elif 'streamData' in file and 'filename' in file['streamData']:
                        name_part = file['streamData']['filename'].strip()
                        logger.log('AioStreams: Using streamData filename: %s' % name_part, log_utils.LOGDEBUG)
                    # Method 3: description field (legacy fallback)
                    else:
                        name_parts = name.split('\n')
                        # Try to find a line that looks like a filename (not size info)
                        for line in name_parts:
                            line = line.strip()
                            if line and '💾' not in line and not line.endswith('Audio'):
                                name_part = line
                                break
                        if not name_part and name_parts:
                            name_part = name_parts[-1].strip()
                        logger.log('AioStreams: Using description fallback: %s' % name_part, log_utils.LOGDEBUG)
                    
                    # Clean the filename
                    name_part = scraper_utils.cleanse_title(name_part)
                    
                    url = hash
                    logger.log('AioStreams: Final processed name: %s' % name_part, log_utils.LOGDEBUG)

                    # Extract quality from filename
                    quality = scraper_utils.get_tor_quality(name_part)
                    
                    # Extract size information - check multiple sources
                    size = 0
                    
                    # Method 1: behaviorHints.videoSize (most accurate)
                    if 'behaviorHints' in file and 'videoSize' in file['behaviorHints']:
                        size = file['behaviorHints']['videoSize'] / (1024 * 1024)  # Convert bytes to MB
                        logger.log('AioStreams: Using behaviorHints size: %s MB' % size, log_utils.LOGDEBUG)
                    # Method 2: streamData.size (fallback)
                    elif 'streamData' in file and 'size' in file['streamData']:
                        size = file['streamData']['size'] / (1024 * 1024)  # Convert bytes to MB
                        logger.log('AioStreams: Using streamData size: %s MB' % size, log_utils.LOGDEBUG)
                    # Method 3: parse from description (legacy)
                    else:
                        size_line = next((line for line in name.split('\n') if '💾' in line), '')
                        size_match = re.search(r'💾\s*([\d.]+)\s*(GiB|MiB|GB|MB)', size_line)
                        if size_match:
                            size_value = float(size_match.group(1))
                            size_unit = size_match.group(2)
                            if size_unit in ['GiB', 'GB']:
                                size = size_value * 1024  # Convert GB to MB
                            else:
                                size = size_value  # MB
                            logger.log('AioStreams: Parsed size from description: %s MB' % size, log_utils.LOGDEBUG)

                    # Determine which debrid service would handle this stream
                    debrid_indicator = self._get_debrid_indicator()
                    # Add debrid service indicator
                    if debrid_indicator:
                        label_parts = [f"[{debrid_indicator}]", name_part]
                    else:
                        label_parts = [name_part]
               
                    if size > 0:
                        if size >= 1024:  # Show in GB if > 1GB
                            label_parts.append(f"{size/1024:.1f}GB")
                        else:
                            label_parts.append(f"{size:.1f}MB")
                    
                    label = " | ".join(label_parts)
                    
                    source_item = {
                        'class': self,
                        'host': 'magnet',
                        'label': label,
                        'multi-part': False,
                        'hash': hash,
                        'name': name_part,
                        'quality': quality,
                        'size': size,
                        'language': 'en',
                        'url': url,
                        'direct': False,
                        'debridonly': True
                    }
                    
                    sources.append(source_item)
                    logger.log('AIOStreams: Added source: %s [%s] [Size: %.1fMB]' % (name_part, quality, size), log_utils.LOGDEBUG)
                    
                except Exception as e:
                    logger.log('AIOStreams: Error processing source: %s' % str(e), log_utils.LOGWARNING)
                    continue

        except Exception as e:
            logger.log('AIOStreams: Unexpected error in get_sources: %s' % str(e), log_utils.LOGERROR)

        logger.log('AIOStreams: Returning %d sources' % len(sources), log_utils.LOGDEBUG)
        return sources

    def search(self, video_type, title, year, season=''):
        """
        Search method implementation for AioStreams scraper.
        AioStreams requires IMDB IDs, so search functionality is limited.
        """
        logger.log('AioStreams: Search not implemented - requires IMDB ID', log_utils.LOGDEBUG)
        return []



