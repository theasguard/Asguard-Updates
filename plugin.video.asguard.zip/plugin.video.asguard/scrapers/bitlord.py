"""
    Asguard Kodi Addon
    Copyright (C) 2024 MrBlamo

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
import logging
import re
import threading
from urllib.parse import quote_plus, unquote_plus
import cache
from asguard_lib import client
from asguard_lib import scraper_utils
from asguard_lib import worker_pool
from asguard_lib.constants import VIDEO_TYPES
import log_utils
import kodi
from . import scraper

logging.basicConfig(level=logging.DEBUG)

logger = log_utils.Logger.get_logger()

class Scraper(scraper.Scraper):
    base_url = "http://www.bitlordsearch.com"
    search_link = '/search?q=%s'
    api_search_link = '/get_list'
    min_seeders = 0

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.headers = cache.get(self._get_token_and_cookies, 1)

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.TVSHOW, VIDEO_TYPES.EPISODE, VIDEO_TYPES.MOVIE])

    @classmethod
    def get_name(cls):
        return 'Bitlord'

    def get_sources(self, video):
        sources = []
        if not video:
            return sources

        year = video.year
        if video.video_type == VIDEO_TYPES.TVSHOW or video.video_type == VIDEO_TYPES.EPISODE:
            title = video.title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
            episode_title = video.ep_title
            hdlr = 'S%02dE%02d' % (int(video.season), int(video.episode))
        else:
            title = video.title.replace('&', 'and').replace('/', ' ').replace('$', 's')
            episode_title = None
            hdlr = year

        query = '%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', title), hdlr)
        url = '%s%s' % (self.base_url, self.search_link % quote_plus(query))
        api_url = '%s%s' % (self.base_url, self.api_search_link)

        if not self.headers:
            return sources

        self.headers.update({'Referer': url})
        query_data = {
            'query': query,
            'offset': 0,
            'limit': 99,
            'filters[field]': 'seeds',
            'filters[sort]': 'desc',
            'filters[time]': 4,
            'filters[category]': 3 if video.video_type == VIDEO_TYPES.MOVIE else 4,
            'filters[adult]': False,
            'filters[risky]': False
        }

        results = client.request(api_url, post=query_data, headers=self.headers, require_debrid=True)
        if not results:
            return sources

        files = json.loads(results)
        if files.get('error'):
            return sources

        for file in files.get('content', []):
            try:
                name = scraper_utils.clean_title(file.get('name'))
                if not scraper_utils.check_title(title, name, year, hdlr, episode_title):
                    continue

                url = unquote_plus(file.get('magnet')).replace('&amp;', '&').replace(' ', '.')
                url = re.sub(r'(&tr=.+)&dn=', '&dn=', url)  # some links on bitlord &tr= before &dn=
                url = url.split('&tr=')[0].split('&xl=')[0]
                hash = re.search(r'btih:(.*?)&', url, re.I).group(1)

                if not episode_title:  # filter for eps returned in movie query (rare but movie and show exists for Run in 2020)
                    ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
                    name_lower = name.lower()
                    if any(re.search(item, name_lower) for item in ep_strings):
                        continue

                try:
                    seeders = file.get('seeds')
                    if self.min_seeders > seeders:
                        continue
                except:
                    seeders = 0

                quality = scraper_utils.get_tor_quality(name)
                info = []
                try:
                    size = file.get('size')
                    size = str(size) + ' GB' if len(str(size)) <= 2 else str(size) + ' MB'  # bitlord size is all over the place between MB and GB
                    dsize, isize = scraper_utils._size(size)
                    info.insert(0, isize)
                except:
                    dsize = 0
                info = ' | '.join(info)

                label = f"{name} | {quality} | {size} | {seeders} seeders"
                item = {
                    'class': self,
                    'host': 'torrent',
                    'label': label,
                    'multi-part': False,
                    'seeders': seeders,
                    'hash': hash,
                    'name': name,
                    'quality': quality,
                    'language': 'en',
                    'url': url,
                    'info': info,
                    'direct': False,
                    'debridonly': True,
                    'size': dsize
                }
                sources.append(item)
            except:
                logger.log('BITLORD', log_utils.LOGERROR)

        return sources

    def _get_token_and_cookies(self):
        headers = None
        try:
            # returned from client (result, response_code, response_headers, headers, cookie)
            post = client.request(self.base_link, output='extended', timeout=10)
            if not post:
                return headers
            token_id = re.findall(r'token\: (.*)\n', post[0])[0]
            token = ''.join(re.findall(token_id + r" ?\+?\= ?'(.*)'", post[0]))
            headers = post[3]
            headers.update({'Cookie': post[4].replace('SameSite=Lax, ', ''), 'X-Request-Token': token})
            return headers
        except:
            logger.log('BITLORD', log_utils.LOGERROR)
            return headers