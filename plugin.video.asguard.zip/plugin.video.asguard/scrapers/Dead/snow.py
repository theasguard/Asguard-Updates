"""
    Asguard Addon
    Copyright (C) 2024

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import json
import logging
import re
import time
import random
import urllib.parse
import urllib.request
import requests
import kodi
import log_utils
from bs4 import BeautifulSoup
from asguard_lib import scraper_utils
from asguard_lib.constants import VIDEO_TYPES, QUALITIES
from asguard_lib.utils2 import i18n
from .. import scraper

try:
    import resolveurl
except ImportError:
    kodi.notify(msg=i18n('smu_failed'), duration=5000)

logger = log_utils.Logger.get_logger()

BASE_URL = 'https://snowfl.com'
SEARCH_URL = '/%s/%s/%s/NONE/NONE/1'
QUALITY_MAP = {'2160': QUALITIES.HD4K, '1080': QUALITIES.HD1080, '720': QUALITIES.HD720, '480': QUALITIES.HIGH}

class Scraper(scraper.Scraper):
    base_url = BASE_URL

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.base_url = kodi.get_setting(f'{self.get_name()}-base_url') or BASE_URL
        self.result_limit = kodi.get_setting(f'{self.get_name()}-result_limit')

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.MOVIE, VIDEO_TYPES.TVSHOW, VIDEO_TYPES.EPISODE])

    @classmethod
    def get_name(cls):
        return 'Snow'

    def resolve_link(self, link):
        return link

    def get_sources(self, video):
        hosters = []
        query = self._get_search_url(video)
        search_url = query
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Referer': 'https://snowfl.com/',
            'TE': 'Trailers',
        }
        
        # Fetch the code from b.min.js
        x = self._http_get('https://snowfl.com')
        regex = 'src="b.min.js(.+?)"'
        matches = re.compile(regex).findall(x)
        if not matches:
            logger.log('No matches found for b.min.js regex', log_utils.LOGWARNING)
            return hosters
        m = matches[0]
        
        x = self._http_get('https://snowfl.com/b.min.js' + m)
        regex = r'isMobile\s*=\s*!1[^"]*"([^"]+)"'
        matches = re.compile(regex).findall(x)
        if not matches:
            logger.log('No matches found for isMobile regex', log_utils.LOGWARNING)
            return hosters
        code = matches[0]
        logger.log(f'Code: {code}', log_utils.LOGDEBUG)
        
        for page in range(1, 4):
            rand_str = random_str()
            params = (
                ('_', str(time.time() * 100)),
            )
            
            response = self._http_get(f'https://snowfl.com/{code}/{search_url}/{rand_str}/{page}/NONE/NONE/1', params=params)
            logger.log(f'Response: {response}', log_utils.LOGDEBUG)
            response = json.loads(response)
            
            for results in response:
                if 'magnet' in results:
                    name = results['name']
                    size = results['size']
                    peer = results['leecher']
                    seed = results['seeder']
                    links = results['magnet']
                    
                    quality = scraper_utils.get_tor_quality(name)
                    
                    try:
                        o_size = size
                        size = float(o_size.replace('GB', '').replace('MB', '').replace(',', '').strip())
                        if 'MB' in o_size:
                            size = size / 1000
                    except Exception as e:
                        size = 0
                    
                    max_size = int(kodi.get_setting("size_limit"))
                    if size < max_size:
                        hoster = {
                            'multi-part': False,
                            'host': 'magnet',
                            'class': self,
                            'quality': quality,
                            'views': None,
                            'rating': None,
                            'url': links,
                            'size': size,
                            'direct': False,
                            'debridonly': True
                        }
                        hosters.append(hoster)
                        logger.log(f'Retrieved sources: {hosters[-1]}', log_utils.LOGDEBUG)
                else:
                    links.append(results)
            
            for results in links:
                site = results['site']
                ur = urllib.parse.quote_plus(results['url']).encode('base64').replace(' ', '').replace('\n', '').replace('\r', '').replace('\t', '')
                response = self._http_get(f'https://snowfl.com/OIcObqNfqpHTDvLKWQDNRlzQPbtqRcoKhtlled/{site}/{ur}', params=params)
                response = json.loads(response)
                
                name = results['name']
                size = results['size']
                peer = results['leecher']
                seed = results['seeder']
                links = response['url']
                
                quality = scraper_utils.get_tor_quality(name)
                
                try:
                    o_size = size
                    size = float(o_size.replace('GB', '').replace('MB', '').replace(',', '').strip())
                    if 'MB' in o_size:
                        size = size / 1000
                except Exception as e:
                    size = 0
                
                max_size = int(kodi.get_setting("size_limit"))
                if size < max_size:
                    hoster = {
                        'multi-part': False,
                        'host': 'magnet',
                        'class': self,
                        'quality': quality,
                        'views': None,
                        'rating': None,
                        'url': links,
                        'size': size,
                        'direct': False,
                        'debridonly': True
                    }
                    hosters.append(hoster)
                    logger.log(f'Retrieved sources: {hosters[-1]}', log_utils.LOGDEBUG)
        
        return hosters

    def _get_search_url(self, video):
        if video.video_type == VIDEO_TYPES.MOVIE:
            search_query = f"{video.title} {video.year}"
        else:
            search_query = f"{video.title} S{int(video.season):02d}"
        search_query = urllib.parse.quote_plus(search_query)
        logger.log(f'Search query: {search_query}', log_utils.LOGDEBUG)
        return scraper_utils.urljoin(self.base_url, SEARCH_URL % (search_query, random_str(), 1))

    def _http_get(self, url, data=None, retry=True, allow_redirect=True, cache_limit=8, require_debrid=True):
        if require_debrid:
            if Scraper.debrid_resolvers is None:
                Scraper.debrid_resolvers = [resolver for resolver in resolveurl.relevant_resolvers() if resolver.isUniversal()]
            if not Scraper.debrid_resolvers:
                logger.log('%s requires debrid: %s' % (self.__module__, Scraper.debrid_resolvers), log_utils.LOGDEBUG)
                return ''
        try:
            headers = {'User-Agent': scraper_utils.get_ua()}
            req = urllib.request.Request(url, data=data, headers=headers)
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return response.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            logger.log(f'HTTP Error: {e.code} - {url}', log_utils.LOGWARNING)
        except urllib.error.URLError as e:
            logger.log(f'URL Error: {e.reason} - {url}', log_utils.LOGWARNING)
        return ''

    @classmethod
    def get_settings(cls):
        settings = super(cls, cls).get_settings()
        name = cls.get_name()
        settings.append(f'         <setting id="{name}-result_limit" label="     {i18n("result_limit")}" type="slider" default="10" range="10,100" option="int" visible="true"/>')
        return settings

def random_str():
    chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP1234567890"
    s = ""
    for x in range(0, 8):
        i = random.randint(0, len(chars) - 1)
        s += chars[i]
    return s