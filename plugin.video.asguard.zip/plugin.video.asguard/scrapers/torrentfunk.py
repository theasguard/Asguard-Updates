"""
    Asguard Kodi Addon
    Copyright (C) 2024 MrBlamo

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import logging
import re
import urllib.parse, urllib.request, urllib.error
from bs4 import BeautifulSoup, SoupStrainer
import kodi
import log_utils
from asguard_lib import scraper_utils, control
from asguard_lib.constants import FORCE_NO_MATCH, VIDEO_TYPES, QUALITIES
from asguard_lib.utils2 import i18n
from . import scraper
import concurrent.futures

try:
    import resolveurl
except ImportError:
    kodi.notify(msg=i18n('smu_failed'), duration=5000)

logging.basicConfig(level=logging.DEBUG)
logger = log_utils.Logger.get_logger()
BASE_URL = "https://torrentfunk.net"
SEARCH_URL = '/torrents?q=%s'

class Scraper(scraper.Scraper):
    base_url = BASE_URL
    debrid_resolvers = resolveurl

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.base_url = kodi.get_setting(f'{self.get_name()}-base_url') or BASE_URL
        self.result_limit = kodi.get_setting(f'{self.get_name()}-result_limit')
        self.min_seeders = 0

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.MOVIE, VIDEO_TYPES.TVSHOW, VIDEO_TYPES.EPISODE])

    @classmethod
    def get_name(cls):
        return 'TorrentFunk'

    def resolve_link(self, link):
        return link

    def get_sources(self, video):
        hosters = []
        query = self._build_query(video)
        search_url = scraper_utils.urljoin(self.base_url, SEARCH_URL % urllib.parse.quote_plus(query))
        logger.log(f'Search URL: {search_url}')      
        html = self._http_get(search_url, require_debrid=True)  

        if not search_url or search_url == FORCE_NO_MATCH:
            return hosters

        # Parse the HTML
        soup = BeautifulSoup(html, "html.parser")
        container = soup.find('div', class_='container mx-auto')

        if not container:
            logger.log('No container found in the HTML', log_utils.LOGERROR)
            return hosters

        specific_div = container.find('div', class_='mx-4 mt-4 space-y-4')
        logger.log(f'Torrentfunk Specific div: {specific_div}')

        if not specific_div:
            logger.log('No specific div found within the container', log_utils.LOGERROR)
            return hosters

        # Find all torrent entries within the specific div
        for card in specific_div.find_all('div', class_='card'):
            try:
                # Extract the title
                title_tag = card.find('h2', class_='card-title')
                if title_tag:
                    title = title_tag.text.strip()
                
                # Extract the magnet link directly from the card
                magnet_tag = card.find('a', href=True, class_='btn', text='Magnet')
                if magnet_tag:
                    magnet = magnet_tag['href']
                else:
                    logger.log(f'Torrentfunk No magnet link found for torrent: {title}')
                    continue

                # Extract the size from the span within the relevant div
                size_div = card.find('div', class_='flex flex-wrap gap-x-3 gap-y-1')
                size_span = size_div.find('span') if size_div else None
                size = size_span.text.strip() if size_span else 'NA'

                # Extract the seeders and leechers
                seeders_tag = card.find('span', class_='text-success')
                seeders = int(seeders_tag.text.strip().replace(',', '')) if seeders_tag else 0

                leechers_tag = card.find('span', class_='text-error')
                leechers = int(leechers_tag.text.strip().replace(',', '')) if leechers_tag else 0

                if self.min_seeders > seeders:
                    logger.log(f'Seeders ({seeders}) less than minimum required ({self.min_seeders})')
                    continue

                quality = scraper_utils.get_tor_quality(title)
                label = f"{title} | {size} | {seeders} ↑ | {leechers} ↓"
                hosters.append({
                    'name': title,
                    'label': label,
                    'multi-part': False,
                    'class': self,
                    'url': magnet,
                    'size': size,
                    'seeders': seeders,
                    'quality': quality,
                    'host': 'magnet',
                    'direct': False,
                    'debridonly': True
                })
                logger.log(f'Added hoster: {hosters[-1]}')
            except Exception as e:
                logger.log(f'Torrentfunk Error parsing entry: {e}', log_utils.LOGERROR)
                continue

        return hosters

    def _build_query(self, video):
        query = video.title
        if video.video_type == VIDEO_TYPES.MOVIE:
            query += f' {video.year}'
        elif video.video_type == VIDEO_TYPES.EPISODE:
            query += f' S{int(video.season):02d}E{int(video.episode):02d}'
        query = query.replace(' ', '+').replace('+-', '-')
        return query

    def _http_get(self, url, data=None, retry=True, allow_redirect=True, cache_limit=8, require_debrid=True):
        if require_debrid:
            if Scraper.debrid_resolvers is None:
                Scraper.debrid_resolvers = [resolver for resolver in resolveurl.relevant_resolvers() if resolver.isUniversal()]
            if not Scraper.debrid_resolvers:
                logger.log('%s requires debrid: %s' % (self.__module__, Scraper.debrid_resolvers), log_utils.LOGDEBUG)
                return ''
        try:
            headers = {'User-Agent': scraper_utils.get_ua()}
            req = urllib.request.Request(url, data=data, headers=headers)
            logging.debug("HTTP request: %s", req)
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return response.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            logger.log(f'HTTP Error: {e.code} - {url}', log_utils.LOGWARNING)
        except urllib.error.URLError as e:
            logger.log(f'URL Error: {e.reason} - {url}', log_utils.LOGWARNING)
        return ''
