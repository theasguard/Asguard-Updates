"""
    Asguard Addon
    Copyright (C) 2024 MrBlamo

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import re
import urllib.parse

from bs4 import BeautifulSoup
import kodi
import cache
import log_utils
from asguard_lib import scraper_utils, control, client
from asguard_lib.constants import FORCE_NO_MATCH, VIDEO_TYPES
from asguard_lib.utils2 import i18n
from . import scraper

logger = log_utils.Logger.get_logger()

BASE_URL = 'https://kickass.cm'
SEARCH_URL = '/usearch/%s'

class Scraper(scraper.Scraper):
    base_url = BASE_URL

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.base_url = kodi.get_setting(f'{self.get_name()}-base_url') or BASE_URL
        self.min_seeders = int(kodi.get_setting(f'{self.get_name()}-min_seeders'))
        self.domains = [
            'kick4ss.com', 'thekat.info', 'kickass.cm', 'kickass.ws', 'kickasst.net',
            'kickasshydra.dev', 'kickasshydra.net', 'kathydra.com', 'kickass.onl',
            'kickasstorrents.id', 'thekat.cc', 'kkat.net', 'kickasstorrents.bz'
        ]
        self._base_link = None

    @property
    def base_link(self):
        if not self._base_link:
            self._base_link = cache.get(self.__get_base_url, 120, 'https://%s' % self.domains[0])
        return self._base_link

    def __get_base_url(self, fallback):
        for domain in self.domains:
            try:
                url = 'https://%s' % domain
                result = client.request(url, limit=1, timeout=5)
                try: result = re.search(r'<title>(.+?)</title>', result, re.I).group(1)
                except: result = None
                if result and 'Kickass' in result: return url
            except:
                logger.log('KICKASS2', log_utils.LOGERROR)
        return fallback

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.MOVIE, VIDEO_TYPES.EPISODE])

    @classmethod
    def get_name(cls):
        return 'Kickass2'

    def get_sources(self, video):
        hosters = []
        query = self.__build_query(video)
        search_url = f"{self.base_link}{SEARCH_URL.format(query=query)}"
        response = self._http_get(search_url, cache_limit=0.25)
        if not response:
            return []

        try:
            soup = BeautifulSoup(response, 'html.parser')
            for row in soup.find_all('tr', id='torrent_latest_torrents'):
                try:
                    name = row.find('a', class_='cellMainLink').text
                    magnet_link = row.find('a', class_='ka-magnet')['href']
                    seeders = int(row.find('td', class_='green center').text)

                    if self.min_seeders > seeders:
                        continue

                    hash = re.search(r'btih:(.*?)&', magnet_link, re.I).group(1)
                    quality = scraper_utils.get_tor_quality(name)

                    hosters.append({
                        'class': self, 'host': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'multi-part': False,
                        'quality': quality, 'language': 'en', 'url': magnet_link, 'direct': False, 'debridonly': True
                    })
                except Exception as e:
                    logger.log(f'Error parsing Kickass2 source: {e}', log_utils.LOGWARNING)
        except Exception as e:
            logger.log(f'Error parsing Kickass2 page: {e}', log_utils.LOGWARNING)

        return hosters

    def __build_query(self, video):
        query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', video.title)
        if video.video_type == VIDEO_TYPES.MOVIE:
            query += f' {video.year}'
        elif video.video_type == VIDEO_TYPES.EPISODE:
            query += f' S{int(video.season):02d}'
        return urllib.parse.quote_plus(query)

    @classmethod
    def get_settings(cls):
        settings = super(cls, cls).get_settings()
        settings = scraper_utils.disable_sub_check(settings)
        name = cls.get_name()
        settings.append(f'         <setting id="{name}-min_seeders" type="slider" range="0,100" option="int" label="     {i18n("min_seeders")}" default="0" visible="eq(-3,true)"/>')
        return settings