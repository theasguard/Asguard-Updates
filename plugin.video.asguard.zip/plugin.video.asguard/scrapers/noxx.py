"""
    Asguard Addon
    Copyright (C) 2024
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import re
import urllib.parse
from bs4 import BeautifulSoup
from asguard_lib import scraper_utils, client
from asguard_lib.constants import VIDEO_TYPES, QUALITIES
from . import scraper
import log_utils

logger = log_utils.Logger.get_logger()

class Scraper(scraper.Scraper):
    base_url = 'https://noxx.to'

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.MOVIE, VIDEO_TYPES.TVSHOW, VIDEO_TYPES.EPISODE])

    @classmethod
    def get_name(cls):
        return 'Noxx'

    def get_sources(self, video):
        sources = []
        source_url = self.get_url(video)
        if not source_url or source_url == scraper_utils.FORCE_NO_MATCH:
            return sources

        url = scraper_utils.urljoin(self.base_url, source_url)
        html = self._http_get(url, cache_limit=1, require_debrid=True)
        logger.log(f'Got html: {html}', log_utils.LOGDEBUG)
        if not html:
            return sources

        soup = BeautifulSoup(html, 'html.parser')
        links = soup.find_all('iframe', src=True)
        buttons = soup.find_all('button', value=True)
        logger.log(f'Found {len(links)} iframe links and {len(buttons)} button links', log_utils.LOGDEBUG)

        for link in links:
            stream_url = link['src']
            if stream_url.startswith('//'):
                stream_url = 'https:' + stream_url
            host = urllib.parse.urlparse(stream_url).hostname
            quality = scraper_utils.blog_get_quality(video, stream_url, host)
            sources.append({
                'quality': quality,
                'url': stream_url,
                'host': host,
                'multi-part': False,
                'class': self,
                'rating': None,
                'views': None,
                'direct': False,
            })
            logger.log('Found source: %s' % sources[-1], log_utils.LOGDEBUG)

        for button in buttons:
            stream_url = button['value']
            host = urllib.parse.urlparse(stream_url).hostname
            quality = scraper_utils.blog_get_quality(video, stream_url, host)
            sources.append({
                'quality': quality,
                'url': stream_url,
                'host': host,
                'multi-part': False,
                'class': self,
                'rating': None,
                'views': None,
                'direct': False,
            })
            logger.log('Found source: %s' % sources[-1], log_utils.LOGDEBUG)

        return sources

    def get_url(self, video):
        if video.video_type == VIDEO_TYPES.MOVIE:
            return self._movie_url(video)
        elif video.video_type == VIDEO_TYPES.TVSHOW:
            return self._tvshow_url(video)
        elif video.video_type == VIDEO_TYPES.EPISODE:
            return self._episode_url(video)
        return None

    def _movie_url(self, video):
        return '/movie/%s' % (scraper_utils.quote_plus(video.title))

    def _tvshow_url(self, video):
        return '/tv/%s' % (scraper_utils.quote_plus(video.title))

    def _episode_url(self, video):
        return '/tv/%s/%s/%s' % (scraper_utils.quote_plus(video.title), video.season, video.episode)

    def _http_get(self, url, data=None, retry=True, allow_redirect=True, cache_limit=8, require_debrid=True):
        try:
            headers = {'User-Agent': scraper_utils.get_ua()}
            req = urllib.request.Request(url, data=data, headers=headers)
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return response.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            logger.log(f'HTTP Error: {e.code} - {url}', log_utils.LOGWARNING)
        except urllib.error.URLError as e:
            logger.log(f'URL Error: {e.reason} - {url}', log_utils.LOGWARNING)
        return ''