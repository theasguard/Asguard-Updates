"""
    Asguard Addon
    Copyright (C) 2024 MrBlamo

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import re
import urllib.parse
import urllib.request
import urllib.error
import kodi
import log_utils
import resolveurl
from asguard_lib.utils2 import i18n
import xbmcgui
from bs4 import BeautifulSoup
from asguard_lib import scraper_utils, control, client
from asguard_lib.constants import FORCE_NO_MATCH, QUALITIES, VIDEO_TYPES
from . import scraper

logger = log_utils.Logger.get_logger()
BASE_URL = 'https://eztvx.to/'
SEARCH_URL = '/search/%s'
QUALITY_MAP = {'1080p': QUALITIES.HD1080, '720p': QUALITIES.HD720, '3D': QUALITIES.HD1080}

class Scraper(scraper.Scraper):
    base_url = BASE_URL

    def __init__(self, timeout=scraper.DEFAULT_TIMEOUT):
        self.timeout = timeout
        self.base_url = kodi.get_setting(f'{self.get_name()}-base_url') or BASE_URL
        self.result_limit = kodi.get_setting(f'{self.get_name()}-result_limit')

    @classmethod
    def provides(cls):
        return frozenset([VIDEO_TYPES.TVSHOW, VIDEO_TYPES.EPISODE])

    @classmethod
    def get_name(cls):
        return 'EZTV'

    def resolve_link(self, link):
        return link

    def get_sources(self, video):
        sources = []
        try:
            source_url = self.get_url(video)
        except TypeError:
            source_url = None

        if not source_url or source_url == FORCE_NO_MATCH:
            title = video.title.replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
            hdlr = 'S%02dE%02d' % (int(video.season), int(video.episode))
            query = '%s %s' % (re.sub(r'[^A-Za-z0-9\s\.]+', '', title), hdlr)
            source_url = SEARCH_URL % urllib.parse.quote_plus(query).replace('+', '-')

        page_url = scraper_utils.urljoin(self.base_url, source_url)
        headers = {'User-Agent': scraper_utils.get_ua()}
        html = self._http_get(page_url, require_debrid=True, cache_limit=.5)

        soup = BeautifulSoup(html, 'html.parser')
        rows = soup.find_all('tr')
        for row in rows:
            try:
                columns = row.find_all('td')
                if len(columns) < 6:
                    continue
                link = re.findall(r'href\s*=\s*["\'](magnet:[^"\']+)["\'].*?title\s*=\s*["\'](.+?)["\']', str(columns[2]), re.DOTALL | re.I)[0]
                url = urllib.parse.unquote_plus(client.replaceHTMLCodes(link[0])).split('&tr')[0]
                hash = re.search(r'btih:(.*?)(?:&|$)', url, re.I).group(1)
                if len(hash) != 40:
                    hash = scraper_utils.base32_to_hex(hash, 'EZTV')
                    url = re.sub(re.search(r'btih:(.*?)(?:&|$)', url).group(1), hash, url)
                name = ''.join(link[1].partition('[eztv]')[:2]).replace(' Torrent: Magnet Link', '')
                name = scraper_utils.clean_title(name)
                quality = scraper_utils.get_tor_quality(name)
                seeders = int(re.search(r'>(\d+|\d+\,\d+)<', columns[5].get_text()).group(1).replace(',', ''))
                sources.append({
                    'class': self,
                    'host': 'torrent',
                    'multi-part': False,
                    'hash': hash,
                    'name': name,
                    'quality': quality,
                    'language': 'en',
                    'url': url,
                    'direct': False,
                    'debridonly': True
                })
            except Exception as e:
                logger.log(f'Error processing EZTV source: {str(e)}', log_utils.LOGERROR)
                continue
        return sources


    def _http_get(self, url, data=None, retry=True, allow_redirect=True, cache_limit=8, require_debrid=True):
        if require_debrid:
            if Scraper.debrid_resolvers is None:
                Scraper.debrid_resolvers = [resolver for resolver in resolveurl.relevant_resolvers() if resolver.isUniversal()]
            if not Scraper.debrid_resolvers:
                logger.log('%s requires debrid: %s' % (self.__module__, Scraper.debrid_resolvers), log_utils.LOGDEBUG)
                return ''
        try:
            headers = {'User-Agent': scraper_utils.get_ua()}
            req = urllib.request.Request(url, data=data, headers=headers)
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return response.read().decode('utf-8')
        except urllib.error.HTTPError as e:
            logger.log(f'HTTP Error: {e.code} - {url}', log_utils.LOGWARNING)
        except urllib.error.URLError as e:
            logger.log(f'URL Error: {e.reason} - {url}', log_utils.LOGWARNING)
        return ''